#!/usr/bin/env python
# coding:utf-8
# pydictor __init__.py file
# plugins directory contains some special password-generator
"""
Copyright (c) 2016-2017 pydictor developers (https://github.com/LandGrey/pydictor)
License: GNU GENERAL PUBLIC LICENSE Version 3
"""
