#!/usr/bin/env python
# coding:utf-8
# pydictor __init__.py file
# rules directory contains some Social Engine Dictionary Builder rules
"""
Copyright (c) 2016-2017 pydictor developers (https://github.com/LandGrey/pydictor)
License: GNU GENERAL PUBLIC LICENSE Version 3
"""
